﻿# Package Manifest

- Package Type: technical-spec
- Package Topic: dual-surface safe rename migration
- Generated At (UTC): 20260402T104703Z
- Source Repo Root: D:/trading advisor 3000

## Included Files
- docs/architecture/dual-surface-safe-rename-migration-technical-specification.md
- docs/architecture/README.md
- docs/architecture/repository-surfaces.md

## Read Order
1. docs/architecture/dual-surface-safe-rename-migration-technical-specification.md
2. docs/architecture/repository-surfaces.md
3. docs/architecture/README.md
